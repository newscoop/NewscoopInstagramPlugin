<?php

namespace Newscoop\InstagramPluginBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NewscoopInstagramPluginBundle extends Bundle
{
}
